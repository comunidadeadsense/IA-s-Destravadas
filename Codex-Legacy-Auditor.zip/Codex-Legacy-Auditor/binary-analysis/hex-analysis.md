# Hexadecimal Analysis

Part of: Codex Legacy auditor

Author: Codex Legacy

## Review Focus

Inspect byte layout, magic values, offsets, encoded strings, padding, anomalous regions using only the supplied binary and available static evidence.

## Method

Record hashes and relevant offsets/sections when available. Correlate multiple indicators rather than relying on a single heuristic.

Entropy, packing, obfuscation, unusual imports, or suspicious strings are not independently sufficient to classify a file as malware.

## Limitations

Static inspection does not establish runtime behavior. Do not claim execution, dynamic analysis, network activity, persistence, or successful payload behavior unless such evidence is actually supplied.
