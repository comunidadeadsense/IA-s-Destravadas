# Code Review Workflow

Part of: Codex Legacy auditor

Author: Codex Legacy

## Workflow

Use this sequence: scope → inventory → threat model → data-flow review → validation → findings.

## Required Discipline

- Record what was inspected and what was unavailable.
- Separate observed facts from derived metrics and inference.
- Validate material findings and actively seek disconfirming evidence.
- Never upgrade a hypothesis to a confirmed conclusion without sufficient evidence.
- Include reproducible verification steps.

## Output

Use the standard nine-part response format defined by `SKILL.md`. Every conclusion must include limitations and confidence.
