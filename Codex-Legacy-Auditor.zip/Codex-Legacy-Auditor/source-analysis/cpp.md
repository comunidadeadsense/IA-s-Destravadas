# C++ Source Analysis

Part of: Codex Legacy auditor

Author: Codex Legacy

## Review Focus

Analyze the supplied C++ code for: RAII and lifetime; smart-pointer correctness; ownership; iterator/reference invalidation; concurrency and races; undefined behavior; exception safety; native resource handling.

## Method

- Identify entry points, trust boundaries, privileged operations, and externally controlled data.
- Trace data from source to security-sensitive sinks.
- Distinguish language guarantees from assumptions made by the program.
- Check error paths, cleanup, concurrency, and platform-specific behavior where applicable.
- Do not report a pattern as a vulnerability without demonstrating a plausible path to security impact.

## Evidence

Quote or reference exact files/functions/lines when available. Classify each conclusion as Observed, Derived, Inferred, Hypothesis/Unconfirmed, or Confirmed.

## Validation

Look for guards, sanitization, ownership/lifetime guarantees, framework protections, generated code, and unreachable paths before escalating severity.
