# JavaScript Source Analysis

Part of: Codex Legacy auditor

Author: Codex Legacy

## Review Focus

Analyze the supplied JavaScript code for: prototype pollution; XSS; dynamic execution; dependency risks; DOM injection; server-side request/input handling; path and command execution.

## Method

- Identify entry points, trust boundaries, privileged operations, and externally controlled data.
- Trace data from source to security-sensitive sinks.
- Distinguish language guarantees from assumptions made by the program.
- Check error paths, cleanup, concurrency, and platform-specific behavior where applicable.
- Do not report a pattern as a vulnerability without demonstrating a plausible path to security impact.

## Evidence

Quote or reference exact files/functions/lines when available. Classify each conclusion as Observed, Derived, Inferred, Hypothesis/Unconfirmed, or Confirmed.

## Validation

Look for guards, sanitization, ownership/lifetime guarantees, framework protections, generated code, and unreachable paths before escalating severity.
