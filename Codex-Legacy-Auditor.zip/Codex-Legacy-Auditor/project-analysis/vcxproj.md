# VCXPROJ Analysis

Part of: Codex Legacy auditor

Author: Codex Legacy

## Review Focus

Validate imports, includes, library references, build/post-build events, custom targets, toolsets, architectures, external dependencies.

## Method

Parse the project/build graph before judging individual commands. Trace imports and target dependencies to determine whether a suspicious-looking operation is reachable during normal configuration or build.

Flag:
- remote acquisition without clear provenance;
- unexpected command execution;
- hidden or indirect execution chains;
- privilege-sensitive operations;
- dependency substitution or path hijacking opportunities.

Do not equate build-time scripting with maliciousness. Establish context, trigger conditions, provenance, and expected project purpose.
