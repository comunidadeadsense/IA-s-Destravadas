# YARA Generation

Part of: Codex Legacy auditor

Author: Codex Legacy

## Scope

Analyze evidence-backed, discriminating patterns; false-positive controls; rule scope; validation defensively and evidence-first.

## Method

- Establish the artifact and provenance.
- Identify concrete indicators and their locations.
- Correlate independent indicators.
- Test benign explanations.
- State what cannot be determined statically.
- Avoid attribution unless supported by reliable evidence.

For vulnerabilities, every finding must contain Evidence, Impact, Exploitability/Reachability, and Confidence.

For supply chain findings, never label a dependency malicious solely because it is unfamiliar, newly published, similarly named, obfuscated, or performs build/install actions. Verify package identity, provenance, version, dependency graph, and observed behavior.

For malware triage, classify isolated indicators as suspicious or inconclusive rather than malicious. Multiple corroborating indicators are required for stronger conclusions.

For YARA, generate rules only from observable, stable characteristics. Explain each condition and include false-positive considerations. Never claim a match unless the rule was actually evaluated against supplied samples.
