# Proteções por Hypervisor

Part of: Codex Legacy auditor

Author: Codex Legacy

## Conceitos

Considere EPT/SLAT, integridade de páginas, VM exits, proteção de componentes críticos e políticas acima do kernel.

## Limitações

Considere:
- suporte de virtualização;
- overhead;
- nested virtualization;
- compatibilidade;
- DMA, que pode exigir controles adicionais.

Não afirme que uma proteção permanece efetiva após comprometimento do kernel sem considerar o modelo de ameaça e o caminho de confiança.
