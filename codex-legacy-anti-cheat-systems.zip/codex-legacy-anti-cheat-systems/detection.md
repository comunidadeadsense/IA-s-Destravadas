# Detecção e Telemetria

Part of: Codex Legacy auditor

Author: Codex Legacy

## Áreas

Considere:
- integridade de código e memória;
- módulos e image mappings;
- handles e processos;
- threads, APCs e contexto;
- drivers e políticas de assinatura;
- callbacks;
- integridade de estruturas relevantes;
- telemetria comportamental;
- replay e análise estatística.

## Métricas

Para modelos e detectores, avalie FPR, FNR, precision, recall, calibração, distribuição populacional e conjuntos de teste separados.

Telemetria reportada pelo cliente deve ser tratada como potencialmente adversarial.
