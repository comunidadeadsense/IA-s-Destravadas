# Forense e Evidências

Part of: Codex Legacy auditor

Author: Codex Legacy

## Evidências

Quando disponíveis, organize:
- hashes;
- logs;
- eventos de driver;
- snapshots;
- módulos;
- traces;
- estado de IOMMU;
- configuração PCIe;
- TPM/PCR;
- ACPI relevante;
- inventário de hardware;
- distribuições estatísticas.

Preserve contexto, timestamp, origem e integridade da evidência.

## Conclusão

Separe claramente fatos, cálculos, inferências e hipóteses.
