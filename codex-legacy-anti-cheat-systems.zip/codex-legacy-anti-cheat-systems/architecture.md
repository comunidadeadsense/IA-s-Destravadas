# Arquitetura Anti-Cheat

Part of: Codex Legacy auditor

Author: Codex Legacy

## Camadas

Considere user mode, serviços privilegiados, componentes in-game, backend e, quando aplicável, hardware-assisted security.

Analise fronteiras de confiança, comunicação entre componentes, integridade, telemetria e resposta.

## Princípio

Não trate uma única camada como prova absoluta. Avalie como sinais independentes podem corroborar uma conclusão sem assumir que sinais correlacionados reduzem automaticamente falsos positivos.
