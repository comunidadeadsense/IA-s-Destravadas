# Detecção Comportamental

Part of: Codex Legacy auditor

Author: Codex Legacy

## Sinais

Analise padrões de entrada, movimento, mira, timing, seleção de alvos, distribuição de resultados e comportamento entre sessões.

Para ML:
- defina features;
- mantenha exemplos positivos confirmados;
- inclua jogadores legítimos de alto nível;
- use hard negatives;
- avalie conjuntos separados;
- monitore deriva e robustez adversarial.

Um padrão estatístico isolado não deve ser convertido diretamente em acusação.
