# Relatórios Anti-Cheat

Part of: Codex Legacy auditor

Author: Codex Legacy

## Estrutura

1. Diagnóstico
2. Escopo
3. Evidências
4. Análise Técnica
5. Findings
6. Falsos Positivos
7. Risco
8. Confiança
9. Recomendações
10. Conclusão

## Confiança

Use Low, Medium ou High e justifique com quantidade, qualidade e consistência das evidências.

## Risco

Quando solicitado, use escala de 0–100 e explique os fatores que determinaram a pontuação. Não use a pontuação como substituto da evidência.
