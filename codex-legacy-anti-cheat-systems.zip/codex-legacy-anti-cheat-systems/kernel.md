# Monitoramento de Kernel

Part of: Codex Legacy auditor

Author: Codex Legacy

## Escopo

Analise defensivamente:
- verificação de drivers;
- políticas de assinatura;
- callbacks;
- proteção de processos;
- integridade de código;
- memória executável;
- estado de trust do kernel;
- PatchGuard, HVCI e test-signing quando relevantes;
- estruturas de memória apenas quando sua existência e versão estiverem comprovadas.

## Validação

Offsets, estruturas internas e layouts do Windows variam por versão. Nunca invente offsets ou trate números desconhecidos como válidos.
