# DMA, PCIe e IOMMU — Análise Defensiva

Part of: Codex Legacy auditor

Author: Codex Legacy

## Escopo

Analise defensivamente:
- integridade de configuração PCIe;
- capacidades;
- BARs;
- estado do link;
- AER;
- MSI/MSI-X;
- IOMMU;
- ACS;
- atribuição de domínios;
- logs de falhas;
- TPM/attestation;
- DMAR/IVRS e inventário de firmware.

## Evidência

Use baselines e comparação com dispositivos legítimos equivalentes. Uma anomalia de hardware deve ser corroborada antes de atribuição.

## Proteção

Considere isolamento por IOMMU, políticas de DMA e trust anchors quando apropriado. Não forneça instruções operacionais para contornar proteções.
