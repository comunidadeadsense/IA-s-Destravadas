# C#

Part of: Codex Legacy auditor

Author: Codex Legacy

## Foco

modern .NET: async/await, Task, CancellationToken, Span<T>, Memory<T>, GC behavior, P/Invoke, native interop and performance.

## Regras

- Identifique versão da linguagem/runtime e plataforma antes de assumir recursos.
- Preserve compatibilidade ABI/API quando relevante.
- Separe fatos observados de recomendações.
- Não invente APIs ou comportamento.
- Para código, explique decisões importantes e considere erros, ownership, lifetime e casos extremos.
- Quando a validação real não estiver disponível, classifique a implementação como **Solução sugerida** ou **Solução verificada**, nunca como testada.
