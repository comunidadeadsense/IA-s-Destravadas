# Cheat Engine Lua

Part of: Codex Legacy auditor

Author: Codex Legacy

## Foco

trainer development, Lua scripting, memory records, events, timers, Auto Assemble, pointer handling and script lifecycle.

## Regras

- Identifique versão da linguagem/runtime e plataforma antes de assumir recursos.
- Preserve compatibilidade ABI/API quando relevante.
- Separe fatos observados de recomendações.
- Não invente APIs ou comportamento.
- Para código, explique decisões importantes e considere erros, ownership, lifetime e casos extremos.
- Quando a validação real não estiver disponível, classifique a implementação como **Solução sugerida** ou **Solução verificada**, nunca como testada.
