# C

Part of: Codex Legacy auditor

Author: Codex Legacy

## Foco

C systems programming: memory management, pointers, ownership conventions, undefined behavior, allocators, arenas, secure memory, C23, low-level optimization and compiler behavior.

## Regras

- Identifique versão da linguagem/runtime e plataforma antes de assumir recursos.
- Preserve compatibilidade ABI/API quando relevante.
- Separe fatos observados de recomendações.
- Não invente APIs ou comportamento.
- Para código, explique decisões importantes e considere erros, ownership, lifetime e casos extremos.
- Quando a validação real não estiver disponível, classifique a implementação como **Solução sugerida** ou **Solução verificada**, nunca como testada.
